import * as React from 'react';
import { Text, View, StyleSheet, FlatList, Pressable, Image, Modal } from 'react-native';
import Constants from 'expo-constants';

const ShowDetalhes = ({ display, toogleModal, mensagem }) => (
  <Modal
    animationType="fade"
    transparent={true}
    visible={display}
    onRequestClose={toogleModal}
  >
    <View style={styles.centeredView}>
      <View style={styles.modalView}>
        <Pressable onPress={toogleModal}>
          <Text style={styles.mensagem}>{mensagem}</Text>
        </Pressable>
      </View>
    </View>

  </Modal>
)

const Pessoa = ({apresentacao, contato, imagem}) => {
  //state para controle do Modal
  const [modal, setModal] = React.useState(false)
  function mudaModal() {
    setModal(!modal)
  }

  return (
    <View>
      <ShowDetalhes display={modal} toogleModal={mudaModal} mensagem={contato} />

      <Pressable onPress={mudaModal}>
        <Image
          style={styles.tinyLogo}
          source={{
            uri: imagem,
          }}
        />
        <Text style={styles.paragraph}>{apresentacao}</Text>
      </Pressable>
    </View>
  )
}

const DATA = [
  {
    "id": 1,
    "name": "Armando Bernardino",
    "email": "armando@email.com",
    "phone": "(11) 91111 1111",
    "job": "Astrônomo",
    "profile": "https://reqres.in/img/faces/1-image.jpg"
  },
  {
    "id": 2,
    "name": "Bárbara Camargo",
    "email": "barbara@email.com",
    "phone": "(11) 92222 2222",
    "job": "Musicista",
    "profile": "https://reqres.in/img/faces/2-image.jpg"
  },
  {
    "id": 3,
    "name": "Diana Elenita",
    "email": "diana@email.com",
    "phone": "(11) 93333 3333",
    "job": "Juíza",
    "profile": "https://reqres.in/img/faces/3-image.jpg"
  },
  {
    "id": 4,
    "name": "Fernando Gomes",
    "email": "fernando@email.com",
    "phone": "(11) 94444 4444",
    "job": "Professor",
    "profile": "https://reqres.in/img/faces/4-image.jpg"
  },
  {
    "id": 5,
    "name": "Heitor Ilha",
    "email": "heitor@email.com",
    "phone": "(11) 95555 5555",
    "job": "Designer",
    "profile": "https://reqres.in/img/faces/5-image.jpg"
  },
  {
    "id": 6,
    "name": "Jaime Leme",
    "email": "jaime@email.com",
    "phone": "(11) 96666 6666",
    "job": "Estilista",
    "profile": "https://reqres.in/img/faces/6-image.jpg"
  }
]

export default function App() {
  //função que renderiza cada item do FlatList
  function meuItem({item}){
    let nameJob = item.name + " - " + item.job
    let contact = item.email + "\n" + item.phone
    return (
      <Pessoa apresentacao={nameJob}
              imagem={item.profile}
              contato={contact}
      />
    )
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={meuItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Calibri',
    color: 'white',
    backgroundColor: '#F5AC2A',
    padding: 10
  },
  tinyLogo: {
    width: 70,
    height: 70,
    alignSelf: 'center'
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 10,
    padding: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  mensagem: {
    fontFamily: 'Calibri',
    fontSize: 14,
    color: 'grey',
    textAlign: 'center'
  }
});
