import * as React from 'react';
import { Text, View, StyleSheet, FlatList, Pressable, Image, Modal, SafeAreaView } from 'react-native';
import Constants from 'expo-constants';

async function executeGet(url, jsonState) {
  //get síncrono com o uso do fetch
  await fetch(url)
    .then(response => {
      if (response.status === 200) {
        console.log('sucesso');
        response.json().then(function (result) {

          //console.log(result);
          jsonState(result)

        });
      } else {
        throw new Error('Erro ao consumir a API!');
      }
    })
    .then(response => {
      //console.debug(response);
    }).catch(error => {
      console.error(error);
    });
}

const ShowDetalhes = ({ display, toogleModal, mensagem }) => (
  <Modal
    animationType="fade"
    transparent={true}
    visible={display}
    onRequestClose={toogleModal}
  >

    <View style={styles.centeredView}>
      <View style={styles.modalView}>
        <Pressable onPress={toogleModal}>
          <Text style={styles.mensagem}>{mensagem}</Text>
        </Pressable>
      </View>
    </View>

  </Modal>

)

const Pessoa = ({ nome, detalhes, imagem }) => {

  //state para controle do Modal
  const [modal, setModal] = React.useState(false)

  function mudaModal() {
    setModal(!modal)
  }

  return (
    <View>
      <ShowDetalhes display={modal} toogleModal={mudaModal} mensagem={detalhes} />

      <Pressable onPress={mudaModal}>
        <Image
          style={styles.tinyLogo}
          source={{
            uri: imagem,
          }}
        />

        <Text style={styles.paragraph}>{nome}</Text>
      </Pressable>
    </View>
  )
}

const ListHeader = () => {
  return (
    <View style={styles.header}>
      <Text style={styles.headerText}>Rick and Morty</Text>
      <Text style={styles.headerSubtext}>Personagens</Text>
    </View>
  )
}

export default function App() {
  const [jsonData, setJsonData] = React.useState({})
  executeGet("https://rickandmortyapi.com/api/character/?page=2", setJsonData)

  //função que renderiza cada item do FlatList
  function meuItem({ item }) {
    let details = "Espécie: " + item.species + "\n" +
                  "Localização: " + item.location.name
    return (
      <Pessoa nome={item.name}
        imagem={item.image}
        detalhes={details}
      />
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={jsonData.results}
        renderItem={meuItem}
        keyExtractor={item => item.id}
        ListHeaderComponent={ListHeader}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#d0f5e2',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Calibri',
    color: 'white',
    backgroundColor: '#ff4589',
    padding: 10,
    borderRadius: 5
  },
  tinyLogo: {
    width: 150,
    height: 150,
    alignSelf: 'center'
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 10,
    padding: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  mensagem: {
    fontFamily: 'Calibri',
    fontSize: 14,
    color: 'grey',
    textAlign: 'center'
  },
  header: {
    textAlign: 'center',
    height: 60,
    backgroundColor: '#0b316e',
    borderBottomWidth: 3,
    borderBottomColor: 'white',
    marginBottom: 20
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Century Gothic',
    color: '#00f078',
    paddingTop: 9
  },
  headerSubtext: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Calibri',
    color: 'white',
    paddingBottom: 9
  }
});